public class ContinueNode extends StatementNode{
    public ContinueNode(){

    }
    public String toString(){
        return "continue";
    }
}
