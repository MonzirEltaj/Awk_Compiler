public class InterpreterDataType {
    String value;

    public InterpreterDataType(){
        this.value = "";
    }
    public InterpreterDataType(String value){
        this.value=value;
    }
    public String toString(){
        return this.value;
    }
}
