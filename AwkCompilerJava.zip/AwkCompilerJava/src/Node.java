/**
 * Abstract class where all nodes extend from
 */
public abstract class Node {
    public abstract String toString();

}

