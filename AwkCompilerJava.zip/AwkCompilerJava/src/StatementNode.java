import java.util.Optional;

public abstract class StatementNode extends Node {
    @Override
    public String toString() {
     return " ";
    }

}
