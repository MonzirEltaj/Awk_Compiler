public class BreakNode extends StatementNode {

    @Override
    public String toString() {
        return "break";
    }
}
